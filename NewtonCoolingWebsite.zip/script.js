
function calculateTime() {
    const T0 = 37; // درجة حرارة الجسم الأولية
    const Tt = parseFloat(document.getElementById("Tt").value);
    const Ta = parseFloat(document.getElementById("Ta").value);
    const k = parseFloat(document.getElementById("k").value);

    if (isNaN(Tt) || isNaN(Ta) || isNaN(k)) {
        alert("يرجى إدخال جميع القيم بشكل صحيح");
        return;
    }

    if (Tt <= Ta) {
        document.getElementById("result").innerText =
            "درجة حرارة الجسم أقل أو تساوي درجة حرارة البيئة، لا يمكن الحساب.";
        return;
    }

    // حساب الزمن
    const time = (1 / k) * Math.log((T0 - Ta) / (Tt - Ta));

    document.getElementById("result").innerText = 
        `وقت الوفاة هو قبل ${time.toFixed(2)} ساعة.`;
}
